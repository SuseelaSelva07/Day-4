package core;

public class MainClass {

	public static void main(String[] args) {
		
		// 1. Method examples and access specifiers
		MethodExample me = new MethodExample();
		//System.out.println(me.display1());
		//System.out.println(me.display2("Sudhesh", "R", 3));
		//me.display();
		
		// 2. Access Modifiers in Java 
		// public
		/*
		System.out.println(me.a);
		System.out.println(me.myName);
		me.a = 50;
		me.myName = "Krishna";
		System.out.println(me.a);
		System.out.println(me.myName);
		*/
		// private
		/*
		System.out.println(me.getA());
//		me.setMyName("kumar");
		System.out.println(me.getMyName());
		*/
		
	}

}
