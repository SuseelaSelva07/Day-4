package core;

public class ArrayMainClass {

	public static void main(String[] args) {
		
		/*
		OneDimensional oneD = new OneDimensional();
		oneD.Normaldisplay();
		oneD.displayUsigForLoop();
		oneD.minmax();
		*/
		
		TwoDimentional twoD = new TwoDimentional();
		twoD.matrixPrintFormat();
		twoD.advancePrintFormat();
		twoD.minmaxtotavg();
	}

}
