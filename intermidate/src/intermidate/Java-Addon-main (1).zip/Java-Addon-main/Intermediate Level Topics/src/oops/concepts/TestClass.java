package oops.concepts;

import oops.concepts.Car.FuelType;

public class TestClass {

	public static void main(String[] args) {
		
		// Exception Handling Test
		/*
		TryCatchFinallyTest err = new TryCatchFinallyTest();
		err.exceptionTest();
		*/
		
		// Inheritance Test
		
		Car shift = new Car("Maruthi", "Red", "Maruthi", 700000, 4, 5, FuelType.Petrol);
		shift.display();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
