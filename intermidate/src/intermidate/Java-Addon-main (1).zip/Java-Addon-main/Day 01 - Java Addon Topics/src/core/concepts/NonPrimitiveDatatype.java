package core.concepts;

public class NonPrimitiveDatatype {

	public static void main(String[] args) {
		
		// 1. String
		String myName = "abcdef12@?.....";
		
		System.out.println("String Representing: " + myName);
		
		// 2. Arrays
		
		int[] a = {10, 20, 30, 40};
		String[] names = {"abc", "def", "ijk"};
		
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(names[1]);

	}

}
