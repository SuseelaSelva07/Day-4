package core.concepts;

public class Variables {

	public static void test() {
		String myName;
		myName = "Addon";
	}

	public static void main(String[] args) {

		// Memory Reservation or Variable declaration
		String name;
		int age;

		// value initialization
		name = "abc";
		age = 25;

		name = "def";

		// Naming rule
		

		System.out.println(name);
//		test();
		
//		System.out.println(myName);
	}

}
