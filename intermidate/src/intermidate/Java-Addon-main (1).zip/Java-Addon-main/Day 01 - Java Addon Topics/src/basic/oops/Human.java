package basic.oops;

public class Human {
	
	public void head() {
		System.out.println("Head function worked");
	}
	
	public void hand() {
		System.out.println("Hand function worked");
	}
	
	public void leg() {
		System.out.println("Leg function worked");
	}
	
	public void run() {
		System.out.println("Run function worked");
	}

}
