package basic.concepts;

import basic.oops.Human;

public class MainClass {

	public static void main(String[] args) {
		
		Human sanjay = new Human();
		sanjay.head();
		sanjay.hand();
		sanjay.leg();
		sanjay.run();
//		Human a = new Human();
//		Human b = new Human();
//		Human c = new Human();
//		Human d = new Human();
//		Human e = new Human();
	}

}
